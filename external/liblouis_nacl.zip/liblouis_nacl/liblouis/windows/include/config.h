#define PACKAGE_VERSION "liblouis-2.4.0"

